
JLAB
Target		3He					3He
Reaction		e+3He->pi_c+X 				e+3He->K_c+X 
Date		2008/11-2009/02				2008/11-2009/02
Energy		electron beam=5.9GeV	  		electron beam=5.9GeV
Paper		Phys.Rev.Lett.107(2011)072003			Phys.Rev.C90(2014)055201 	         																											
				 
Bin		x(0.16<x<0.35)				x(0.1<x<0.4)
		
	
